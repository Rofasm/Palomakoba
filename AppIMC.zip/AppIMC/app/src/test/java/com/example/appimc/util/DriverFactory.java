package com.example.appimc.util;

private static AndroidDriver<MobileElement> driver;

public static AndroidDriver<MobileElement> getDriver() {
    if (driver == null) {
        criarDriver();
        }
        return driver;

    private static void criarDriver() {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability("platformName", "Android");
        desiredCapabilities.setCapability("appium:deviceName", "emulator-5554");
        desiredCapabilities.setCapability("appium:automationName", "uiautomator2");
        desiredCapabilities.setCapability("appium:appPackage", "com.example.appimc");
        desiredCapabilities.setCapability("appium:appActivity", "com.example.appimc.MainActivity");
        desiredCapabilities.setCapability("appium:ensureWebviewsHavePages", true);
        desiredCapabilities.setCapability("appium:nativeWebScreenshot", true);
        desiredCapabilities.setCapability("appium:newCommandTimeout", 3600);
        desiredCapabilities.setCapability("appium:connectHardwareKeyboard", true);

        try
        {
            URL remoteUrl = new URL("http://127.0.0.1:4723/wd/hub");
            driver = new AndroidDriver(remoteUrl, desiredCapabilities);
        }catch (MalformedURLExeption e)
        {
            e.printStackTrace();
        }
    }
    public static void finalizarDriver()
        {
            if (driver != null)
            {
            driver.quit();
            driver = null;
            }
        }
}
