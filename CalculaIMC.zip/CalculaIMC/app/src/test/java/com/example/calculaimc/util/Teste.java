package com.example.calculaimc.util;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Teste {

    private AndroidDriver driver;

    @Before
    public void setUp() throws MalformedURLException {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability("platformName", "Android");
        desiredCapabilities.setCapability("appium:ddeviceName", "emulator-5554");
        desiredCapabilities.setCapability("appium:automationName", "uiautomator2");
        desiredCapabilities.setCapability("appium:appPackage", "com.example.calculaimc");
        desiredCapabilities.setCapability("appium:appActivity", "com.example.calculaimc.MainActivity");
        desiredCapabilities.setCapability("appium:ensureWebviewsHavePages", true);
        desiredCapabilities.setCapability("appium:nativeWebScreenshot", true);
        desiredCapabilities.setCapability("appium:newCommandTimeout", 3600);
        desiredCapabilities.setCapability("appium:connectHardwareKeyboard", true);

        URL remoteUrl = new URL("http://127.0.0.1:4723/wd/hub");

        driver = new AndroidDriver(remoteUrl, desiredCapabilities);
    }

    @Test
    public void sampleTest() throws InterruptedException {
        Thread thread = new Thread();
        MobileElement el1 = (MobileElement) driver.findElementById("com.example.calculaimc:id/edtnome");
        el1.sendKeys("Robson");
        MobileElement el2 = (MobileElement) driver.findElementById("com.example.calculaimc:id/edtpeso");
        el2.sendKeys("60");
        MobileElement el3 = (MobileElement) driver.findElementById("com.example.calculaimc:id/edtaltura");
        el3.sendKeys("185");
        MobileElement el4 = (MobileElement) driver.findElementById("com.example.calculaimc:id/rbmasculino");
        el4.click();
        MobileElement el5 = (MobileElement) driver.findElementById("com.example.calculaimc:id/btcalcular");
        el5.click();
        thread.sleep(3000);
        MobileElement el6 = (MobileElement) driver.findElementById("android:id/message");
        el6.click();
        Assert.assertEquals("IMC = 17.53\n Abaixo do normal\n",el6.getText());

    }

    @After
    public void tearDown() {
        driver.quit();
    }
}