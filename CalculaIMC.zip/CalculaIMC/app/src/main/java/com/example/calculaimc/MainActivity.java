package com.example.calculaimc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.app.AlertDialog;

public class MainActivity extends AppCompatActivity {
    Button btcalcular;
    RadioGroup grupo;
    EditText edtnome, edtpeso, edtaltura;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtnome = findViewById(R.id.edtnome);
        edtpeso = findViewById(R.id.edtpeso);
        edtaltura = findViewById(R.id.edtaltura);
        btcalcular = findViewById(R.id.btcalcular);
        grupo = findViewById(R.id.grupo);
        btcalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double imc;
                String msg;
                double peso = Double.parseDouble(edtpeso.getText().toString());
                double altura = Double.parseDouble(edtaltura.getText().toString())/100;
                imc = peso/(altura*altura);
                int opcao = grupo.getCheckedRadioButtonId();
                if (opcao==R.id.rbmasculino){
                    if (imc < 20){
                        msg = "Abaixo do normal";
                    } else if  ((imc >= 20) && (imc <= 24.9)){
                        msg = "Normal";
                    }else if ((imc>24.9)&&(imc <=29.9)){
                        msg="Obesidade leve";
                    } else if ((imc >29.9)&&(imc<=43)){
                        msg ="Obesidade moderada";
                    } else msg ="Obesidade Morbida";
                }
                else
                {    // radio Buttom FEMININO
                    if (imc < 19){
                        msg = "Abaixo do normal";
                    } else if  ((imc >= 19) && (imc <= 23.9)){
                        msg = "Normal";
                    }else if ((imc>23.9)&&(imc <=28.9)){
                        msg="Obesidade leve";
                    } else if ((imc >28.9)&&(imc<=39)){
                        msg ="Obesidade moderada";
                    } else msg ="Obesidade Morbida";
                }
                AlertDialog.Builder janela=new AlertDialog.Builder(MainActivity.this);
                janela.setTitle("Calculo IMC");
                janela.setMessage(String.format("IMC = %.2f\n %s\n",imc,msg));
                janela.setNeutralButton("OK",null);
                janela.show();
            }
        });
    }
}