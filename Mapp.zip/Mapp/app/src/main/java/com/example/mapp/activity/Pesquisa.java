package com.example.mapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.mapp.R;

public class Pesquisa extends AppCompatActivity {
    Button btnProc, fabFav;
    RecyclerView recyclerView;
    TextView txRua, txtEstado, txtCidade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesquisa);
    }
}